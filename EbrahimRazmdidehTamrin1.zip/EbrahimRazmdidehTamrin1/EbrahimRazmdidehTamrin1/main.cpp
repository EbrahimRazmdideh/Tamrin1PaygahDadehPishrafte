﻿#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <random>
#include <iterator>
#include <string>
#include <cstdio>
#include <cstdint>
#include <thread>
#include <mutex>
#include <queue>
#include <functional>

const int64_t NUM_COUNT = 200000000; // 200 میلیون عدد
const int64_t CHUNK_SIZE = 12500000; // هر تکه شامل 12.5 میلیون عدد (~100MB)
const int THREAD_COUNT = 4; // تعداد رشته‌ها برای پردازش موازی

std::mutex mtx;

// تولید اعداد تصادفی و نوشتن به فایل
void generate_random_numbers(const std::string& filename) {
    std::ofstream outfile(filename);
    std::random_device rd;
    std::mt19937_64 gen(rd());
    std::uniform_int_distribution<int64_t> dis;

    for (int64_t i = 0; i < NUM_COUNT; ++i) {
        int64_t num = dis(gen);
        outfile << num << "\n";
    }

    outfile.close();
}

// تابع برای مرتب‌سازی یک تکه در یک رشته مجزا
void sort_chunk(const std::vector<int64_t>& buffer, const std::string& chunk_filename) {
    std::vector<int64_t> local_buffer = buffer;
    std::sort(local_buffer.begin(), local_buffer.end());
    std::ofstream chunk_file(chunk_filename);
    for (const auto& val : local_buffer) {
        chunk_file << val << "\n";
    }
    chunk_file.close();
}

// تقسیم و مرتب‌سازی تکه‌ها با استفاده از رشته‌ها
std::vector<std::string> split_and_sort_chunks(const std::string& filename) {
    std::ifstream infile(filename);
    std::vector<std::string> chunk_files;
    std::vector<int64_t> buffer;
    buffer.reserve(CHUNK_SIZE);

    int chunk_idx = 0;
    int64_t num;
    std::vector<std::thread> threads;
    while (infile >> num) {
        buffer.push_back(num);
        if (buffer.size() >= CHUNK_SIZE) {
            std::string chunk_filename = "chunk_" + std::to_string(chunk_idx++) + ".txt";
            chunk_files.push_back(chunk_filename);
            threads.emplace_back(sort_chunk, buffer, chunk_filename);
            buffer.clear();
        }
    }

    if (!buffer.empty()) {
        std::string chunk_filename = "chunk_" + std::to_string(chunk_idx++) + ".txt";
        chunk_files.push_back(chunk_filename);
        threads.emplace_back(sort_chunk, buffer, chunk_filename);
    }

    for (auto& t : threads) {
        t.join();
    }

    infile.close();
    return chunk_files;
}

// ترکیب و مرتب‌سازی تکه‌ها
void merge_chunks(const std::vector<std::string>& chunk_files, const std::string& output_file) {
    std::vector<std::ifstream> inputs(chunk_files.size());
    for (size_t i = 0; i < chunk_files.size(); ++i) {
        inputs[i].open(chunk_files[i]);
    }

    std::ofstream outfile(output_file);
    auto compare = [](std::pair<int64_t, size_t> a, std::pair<int64_t, size_t> b) {
        return a.first > b.first;
        };
    std::vector<std::pair<int64_t, size_t>> min_heap;

    for (size_t i = 0; i < inputs.size(); ++i) {
        int64_t num;
        if (inputs[i] >> num) {
            min_heap.push_back({ num, i });
        }
    }

    std::make_heap(min_heap.begin(), min_heap.end(), compare);

    while (!min_heap.empty()) {
        std::pop_heap(min_heap.begin(), min_heap.end(), compare);
        auto min_pair = min_heap.back();
        min_heap.pop_back();

        outfile << min_pair.first << "\n";

        int64_t num;
        if (inputs[min_pair.second] >> num) {
            min_heap.push_back({ num, min_pair.second });
            std::push_heap(min_heap.begin(), min_heap.end(), compare);
        }
    }

    outfile.close();
    for (auto& in : inputs) {
        in.close();
    }
}

int main() {
    std::string input_file = "random_numbers.txt";
    std::string sorted_file = "sorted_numbers.txt";

    std::cout << "Generating random numbers..." << std::endl;
    generate_random_numbers(input_file);

    std::cout << "Splitting and sorting chunks..." << std::endl;
    std::vector<std::string> chunk_files = split_and_sort_chunks(input_file);

    std::cout << "Merging sorted chunks..." << std::endl;
    merge_chunks(chunk_files, sorted_file);

    std::cout << "Sorting complete." << std::endl;

    // پاک کردن فایل‌های تکه‌ها
    for (const auto& filename : chunk_files) {
        std::remove(filename.c_str());
    }

    return 0;
}
